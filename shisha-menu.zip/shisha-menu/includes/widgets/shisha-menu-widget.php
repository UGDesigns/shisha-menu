<?php
namespace ShishaMenu\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Repeater;

class Shisha_Menu_Widget extends Widget_Base {

	public function get_name() {
		return 'shisha-menu';
	}

	public function get_title() {
		return esc_html__( 'Shisha Menu', 'shisha-menu' );
	}

	public function get_icon() {
		return 'eicon-menu-card';
	}

	public function get_categories() {
		return [ 'shisha-menu' ];
	}

	public function get_keywords() {
		return [ 'menu', 'shisha', 'restaurant', 'bar', 'tabak', 'getränke', 'snacks' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_menu_items',
			[
				'label' => esc_html__( 'Menü Einträge', 'shisha-menu' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_type',
			[
				'label' => esc_html__( 'Typ', 'shisha-menu' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'category',
				'options' => [
					'category' => esc_html__( 'Kategorie', 'shisha-menu' ),
					'subcategory' => esc_html__( 'Unterkategorie', 'shisha-menu' ),
					'item' => esc_html__( 'Menü Eintrag', 'shisha-menu' ),
				],
			]
		);

		$repeater->add_control(
			'category_name',
			[
				'label' => esc_html__( 'Kategorie Name', 'shisha-menu' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Neue Kategorie', 'shisha-menu' ),
				'condition' => [
					'item_type' => 'category',
				],
			]
		);

		$repeater->add_control(
			'subcategory_name',
			[
				'label' => esc_html__( 'Unterkategorie Name', 'shisha-menu' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Neue Unterkategorie', 'shisha-menu' ),
				'condition' => [
					'item_type' => 'subcategory',
				],
			]
		);

		$repeater->add_control(
			'item_name',
			[
				'label' => esc_html__( 'Name', 'shisha-menu' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Menü Eintrag', 'shisha-menu' ),
				'condition' => [
					'item_type' => 'item',
				],
			]
		);

		$repeater->add_control(
			'item_description',
			[
				'label' => esc_html__( 'Beschreibung', 'shisha-menu' ),
				'type' => Controls_Manager::TEXTAREA,
				'rows' => 3,
				'default' => '',
				'condition' => [
					'item_type' => 'item',
				],
			]
		);

		$repeater->add_control(
			'item_price',
			[
				'label' => esc_html__( 'Preis', 'shisha-menu' ),
				'type' => Controls_Manager::TEXT,
				'default' => '0,00',
				'condition' => [
					'item_type' => 'item',
				],
			]
		);

		$repeater->add_control(
			'item_image',
			[
				'label' => esc_html__( 'Bild', 'shisha-menu' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'item_type' => 'item',
				],
			]
		);

		$this->add_control(
			'menu_items',
			[
				'label' => esc_html__( 'Menü Einträge', 'shisha-menu' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'item_type' => 'category',
						'category_name' => esc_html__( 'Tabak Sorten', 'shisha-menu' ),
					],
					[
						'item_type' => 'subcategory',
						'subcategory_name' => esc_html__( 'Premium Tabak', 'shisha-menu' ),
					],
					[
						'item_type' => 'item',
						'item_name' => esc_html__( 'Doppelapfel', 'shisha-menu' ),
						'item_description' => esc_html__( 'Klassischer Doppelapfel Geschmack', 'shisha-menu' ),
						'item_price' => '15,00',
					],
				],
				'title_field' => '{{{ item_type === "category" ? category_name : (item_type === "subcategory" ? subcategory_name : item_name) }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_layout',
			[
				'label' => esc_html__( 'Layout', 'shisha-menu' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'layout_style',
			[
				'label' => esc_html__( 'Layout Stil', 'shisha-menu' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'grid',
				'options' => [
					'list' => esc_html__( 'Liste', 'shisha-menu' ),
					'grid' => esc_html__( 'Raster', 'shisha-menu' ),
					'cards' => esc_html__( 'Karten', 'shisha-menu' ),
				],
			]
		);

		$this->add_responsive_control(
			'columns',
			[
				'label' => esc_html__( 'Spalten', 'shisha-menu' ),
				'type' => Controls_Manager::SELECT,
				'default' => '2',
				'options' => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
				],
				'condition' => [
					'layout_style' => [ 'grid', 'cards' ],
				],
				'selectors' => [
					'{{WRAPPER}} .shisha-menu-grid' => 'grid-template-columns: repeat({{VALUE}}, 1fr);',
				],
			]
		);

		$this->add_control(
			'show_images',
			[
				'label' => esc_html__( 'Bilder anzeigen', 'shisha-menu' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Ja', 'shisha-menu' ),
				'label_off' => esc_html__( 'Nein', 'shisha-menu' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'currency_symbol',
			[
				'label' => esc_html__( 'Währungssymbol', 'shisha-menu' ),
				'type' => Controls_Manager::TEXT,
				'default' => '€',
			]
		);

		$this->add_control(
			'currency_position',
			[
				'label' => esc_html__( 'Währungsposition', 'shisha-menu' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'after',
				'options' => [
					'before' => esc_html__( 'Vor dem Preis', 'shisha-menu' ),
					'after' => esc_html__( 'Nach dem Preis', 'shisha-menu' ),
				],
			]
		);

		$this->end_controls_section();

		// Style Controls
		$this->register_style_controls();
	}

	protected function register_style_controls() {
		// Container Style
		$this->start_controls_section(
			'section_container_style',
			[
				'label' => esc_html__( 'Container', 'shisha-menu' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'container_background',
				'label' => esc_html__( 'Hintergrund', 'shisha-menu' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .shisha-menu-container',
			]
		);

		$this->add_responsive_control(
			'container_padding',
			[
				'label' => esc_html__( 'Innenabstand', 'shisha-menu' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .shisha-menu-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'container_border',
				'label' => esc_html__( 'Rahmen', 'shisha-menu' ),
				'selector' => '{{WRAPPER}} .shisha-menu-container',
			]
		);

		$this->add_control(
			'container_border_radius',
			[
				'label' => esc_html__( 'Rahmenradius', 'shisha-menu' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shisha-menu-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'container_box_shadow',
				'label' => esc_html__( 'Schatten', 'shisha-menu' ),
				'selector' => '{{WRAPPER}} .shisha-menu-container',
			]
		);

		$this->end_controls_section();

		// Category Style
		$this->start_controls_section(
			'section_category_style',
			[
				'label' => esc_html__( 'Kategorien', 'shisha-menu' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'category_color',
			[
				'label' => esc_html__( 'Textfarbe', 'shisha-menu' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shisha-menu-category h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'category_typography',
				'label' => esc_html__( 'Typografie', 'shisha-menu' ),
				'selector' => '{{WRAPPER}} .shisha-menu-category h2',
			]
		);

		$this->add_responsive_control(
			'category_spacing',
			[
				'label' => esc_html__( 'Abstand', 'shisha-menu' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .shisha-menu-category' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Subcategory Style
		$this->start_controls_section(
			'section_subcategory_style',
			[
				'label' => esc_html__( 'Unterkategorien', 'shisha-menu' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'subcategory_color',
			[
				'label' => esc_html__( 'Textfarbe', 'shisha-menu' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shisha-menu-subcategory h3' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'subcategory_typography',
				'label' => esc_html__( 'Typografie', 'shisha-menu' ),
				'selector' => '{{WRAPPER}} .shisha-menu-subcategory h3',
			]
		);

		$this->end_controls_section();

		// Item Style
		$this->start_controls_section(
			'section_item_style',
			[
				'label' => esc_html__( 'Menü Einträge', 'shisha-menu' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_name_color',
			[
				'label' => esc_html__( 'Name Farbe', 'shisha-menu' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shisha-menu-item-name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_name_typography',
				'label' => esc_html__( 'Name Typografie', 'shisha-menu' ),
				'selector' => '{{WRAPPER}} .shisha-menu-item-name',
			]
		);

		$this->add_control(
			'item_description_color',
			[
				'label' => esc_html__( 'Beschreibung Farbe', 'shisha-menu' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shisha-menu-item-description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_description_typography',
				'label' => esc_html__( 'Beschreibung Typografie', 'shisha-menu' ),
				'selector' => '{{WRAPPER}} .shisha-menu-item-description',
			]
		);

		$this->add_control(
			'item_price_color',
			[
				'label' => esc_html__( 'Preis Farbe', 'shisha-menu' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shisha-menu-item-price' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_price_typography',
				'label' => esc_html__( 'Preis Typografie', 'shisha-menu' ),
				'selector' => '{{WRAPPER}} .shisha-menu-item-price',
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$menu_items = $settings['menu_items'];

		if ( empty( $menu_items ) ) {
			return;
		}

		$this->add_render_attribute( 'wrapper', 'class', 'shisha-menu-container' );
		$this->add_render_attribute( 'wrapper', 'class', 'shisha-menu-layout-' . $settings['layout_style'] );

		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<?php
			$current_category = '';
			$current_subcategory = '';
			$category_open = false;
			$subcategory_open = false;

			foreach ( $menu_items as $index => $item ) {
				if ( 'category' === $item['item_type'] ) {
					// Close previous subcategory and category if open
					if ( $subcategory_open ) {
						echo '</div>'; // Close subcategory items
						echo '</div>'; // Close subcategory
						$subcategory_open = false;
					}
					if ( $category_open ) {
						echo '</div>'; // Close category items
						echo '</div>'; // Close category
					}

					$current_category = $item['category_name'];
					$current_subcategory = '';
					?>
					<div class="shisha-menu-category">
						<h2><?php echo esc_html( $item['category_name'] ); ?></h2>
						<div class="shisha-menu-category-items <?php echo 'grid' === $settings['layout_style'] || 'cards' === $settings['layout_style'] ? 'shisha-menu-grid' : ''; ?>">
					<?php
					$category_open = true;
				} elseif ( 'subcategory' === $item['item_type'] ) {
					// Close previous subcategory if open
					if ( $subcategory_open ) {
						echo '</div>'; // Close subcategory items
						echo '</div>'; // Close subcategory
					}

					$current_subcategory = $item['subcategory_name'];
					?>
					<div class="shisha-menu-subcategory">
						<h3><?php echo esc_html( $item['subcategory_name'] ); ?></h3>
						<div class="shisha-menu-subcategory-items">
					<?php
					$subcategory_open = true;
				} elseif ( 'item' === $item['item_type'] ) {
					$this->render_menu_item( $item, $settings );
				}
			}

			// Close any open tags
			if ( $subcategory_open ) {
				echo '</div>'; // Close subcategory items
				echo '</div>'; // Close subcategory
			}
			if ( $category_open ) {
				echo '</div>'; // Close category items
				echo '</div>'; // Close category
			}
			?>
		</div>
		<?php
	}

	protected function render_menu_item( $item, $settings ) {
		$show_images = 'yes' === $settings['show_images'];
		$currency_symbol = $settings['currency_symbol'];
		$currency_position = $settings['currency_position'];

		?>
		<div class="shisha-menu-item">
			<?php if ( $show_images && ! empty( $item['item_image']['url'] ) ) : ?>
				<div class="shisha-menu-item-image">
					<img src="<?php echo esc_url( $item['item_image']['url'] ); ?>" 
						 alt="<?php echo esc_attr( $item['item_name'] ); ?>"
						 loading="lazy">
				</div>
			<?php endif; ?>
			
			<div class="shisha-menu-item-content">
				<div class="shisha-menu-item-header">
					<h4 class="shisha-menu-item-name"><?php echo esc_html( $item['item_name'] ); ?></h4>
					<span class="shisha-menu-item-price">
						<?php
						if ( 'before' === $currency_position ) {
							echo esc_html( $currency_symbol . ' ' . $item['item_price'] );
						} else {
							echo esc_html( $item['item_price'] . ' ' . $currency_symbol );
						}
						?>
					</span>
				</div>
				
				<?php if ( ! empty( $item['item_description'] ) ) : ?>
					<p class="shisha-menu-item-description">
						<?php echo esc_html( $item['item_description'] ); ?>
					</p>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	protected function content_template() {
		?>
		<#
		if ( settings.menu_items.length ) {
			#>
			<div class="shisha-menu-container shisha-menu-layout-{{ settings.layout_style }}">
				<#
				var currentCategory = '';
				var currentSubcategory = '';
				var categoryOpen = false;
				var subcategoryOpen = false;

				_.each( settings.menu_items, function( item, index ) {
					if ( 'category' === item.item_type ) {
						if ( subcategoryOpen ) {
							#></div></div><#
							subcategoryOpen = false;
						}
						if ( categoryOpen ) {
							#></div></div><#
						}

						currentCategory = item.category_name;
						currentSubcategory = '';
						#>
						<div class="shisha-menu-category">
							<h2>{{{ item.category_name }}}</h2>
							<div class="shisha-menu-category-items {{ 'grid' === settings.layout_style || 'cards' === settings.layout_style ? 'shisha-menu-grid' : '' }}">
						<#
						categoryOpen = true;
					} else if ( 'subcategory' === item.item_type ) {
						if ( subcategoryOpen ) {
							#></div></div><#
						}

						currentSubcategory = item.subcategory_name;
						#>
						<div class="shisha-menu-subcategory">
							<h3>{{{ item.subcategory_name }}}</h3>
							<div class="shisha-menu-subcategory-items">
						<#
						subcategoryOpen = true;
					} else if ( 'item' === item.item_type ) {
						var showImages = 'yes' === settings.show_images;
						var currencySymbol = settings.currency_symbol;
						var currencyPosition = settings.currency_position;
						#>
						<div class="shisha-menu-item">
							<# if ( showImages && item.item_image.url ) { #>
								<div class="shisha-menu-item-image">
									<img src="{{ item.item_image.url }}" alt="{{ item.item_name }}" loading="lazy">
								</div>
							<# } #>
							
							<div class="shisha-menu-item-content">
								<div class="shisha-menu-item-header">
									<h4 class="shisha-menu-item-name">{{{ item.item_name }}}</h4>
									<span class="shisha-menu-item-price">
										<# if ( 'before' === currencyPosition ) { #>
											{{{ currencySymbol }}} {{{ item.item_price }}}
										<# } else { #>
											{{{ item.item_price }}} {{{ currencySymbol }}}
										<# } #>
									</span>
								</div>
								
								<# if ( item.item_description ) { #>
									<p class="shisha-menu-item-description">
										{{{ item.item_description }}}
									</p>
								<# } #>
							</div>
						</div>
						<#
					}
				} );

				if ( subcategoryOpen ) {
					#></div></div><#
				}
				if ( categoryOpen ) {
					#></div></div><#
				}
				#>
			</div>
			<#
		}
		#>
		<?php
	}
}