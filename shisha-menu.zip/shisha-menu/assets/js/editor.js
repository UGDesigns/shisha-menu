(function() {
	'use strict';

	// Log when widget is loaded in editor
	if ( window.elementor ) {
		elementor.on( 'panel:init', function() {
			console.log( 'Shisha Menu: Elementor panel initialized' );
		});
	}
})();