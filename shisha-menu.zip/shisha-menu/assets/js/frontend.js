(function($) {
	'use strict';

	/**
	 * Shisha Menu Frontend Handler
	 */
	var ShishaMenuFrontend = {
		
		init: function() {
			this.bindEvents();
			this.enhanceAccessibility();
		},

		bindEvents: function() {
			// Add any interactive functionality here
			// For example: filtering, search, etc.
		},

		enhanceAccessibility: function() {
			// Ensure proper ARIA labels
			$('.shisha-menu-category').each(function() {
				var $category = $(this);
				var categoryName = $category.find('h2').text();
				$category.attr('aria-label', categoryName);
			});

			$('.shisha-menu-subcategory').each(function() {
				var $subcategory = $(this);
				var subcategoryName = $subcategory.find('h3').text();
				$subcategory.attr('aria-label', subcategoryName);
			});

			// Add role attributes for better screen reader support
			$('.shisha-menu-item').attr('role', 'article');
			$('.shisha-menu-item-price').attr('aria-label', function() {
				return elementorFrontend.config.i18n.price + ': ' + $(this).text();
			});
		}
	};

	// Initialize on Elementor frontend ready
	$(window).on('elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction('frontend/element_ready/shisha-menu.default', function($scope) {
			ShishaMenuFrontend.init();
		});
	});

})(jQuery);